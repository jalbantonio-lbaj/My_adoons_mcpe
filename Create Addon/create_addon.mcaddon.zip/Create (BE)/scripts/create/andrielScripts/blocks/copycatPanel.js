const COPYCAT_MATERIALS = new Map([
    ["minecraft:stone", 1],
    ["minecraft:dirt", 2],
    ["minecraft:grass_block", 3],
    ["minecraft:cobblestone", 4],
    ["minecraft:oak_planks", 5],
    ["minecraft:spruce_planks", 6],
    ["minecraft:birch_planks", 7],
    ["minecraft:jungle_planks", 8],
    ["minecraft:acacia_planks", 9],
    ["minecraft:dark_oak_planks", 10],
    ["minecraft:mangrove_planks", 11],
    ["minecraft:cherry_planks", 12],
    ["minecraft:sand", 13],
    ["minecraft:red_sand", 14],
    ["minecraft:gravel", 15],
    ["minecraft:granite", 16],
    ["minecraft:polished_granite", 17],
    ["minecraft:diorite", 18],
    ["minecraft:polished_diorite", 19],
    ["minecraft:andesite", 20],
    ["minecraft:polished_andesite", 21],
    ["minecraft:deepslate", 22],
    ["minecraft:cobbled_deepslate", 23],
    ["minecraft:polished_deepslate", 24],
    ["minecraft:deepslate_bricks", 25],
    ["minecraft:deepslate_tiles", 26],
    ["minecraft:calcite", 27],
    ["minecraft:tuff", 28],
    ["minecraft:clay", 29],
    ["minecraft:mud", 30],
    ["minecraft:packed_mud", 31],
    ["minecraft:mud_bricks", 32],
    ["minecraft:snow", 33],
    ["minecraft:ice", 34],
    ["minecraft:packed_ice", 35],
    ["minecraft:blue_ice", 36],
    ["minecraft:coal_block", 37],
    ["minecraft:iron_block", 38],
    ["minecraft:gold_block", 39],
    ["minecraft:diamond_block", 40],
    ["minecraft:emerald_block", 41],
    ["minecraft:lapis_block", 42],
    ["minecraft:redstone_block", 43],
    ["minecraft:raw_iron_block", 44],
    ["minecraft:raw_gold_block", 45],
    ["minecraft:raw_copper_block", 46],
    ["minecraft:copper_block", 47],
    ["minecraft:quartz_block", 48],
    ["minecraft:smooth_quartz", 49],
    ["minecraft:quartz_bricks", 50],
    ["minecraft:blackstone", 51],
    ["minecraft:polished_blackstone", 52],
    ["minecraft:polished_blackstone_bricks", 53],
    ["minecraft:nether_brick", 54],
    ["minecraft:red_nether_brick", 55],
    ["minecraft:prismarine", 56],
    ["minecraft:dark_prismarine", 57],
    ["minecraft:sea_lantern", 58],
    ["minecraft:purpur_block", 59],
    ["minecraft:end_bricks", 60],
    ["minecraft:pale_oak_planks", 61],
    ["minecraft:bamboo_planks", 62],
    ["minecraft:crimson_planks", 63],
    ["minecraft:warped_planks", 64],
    ["minecraft:brick_block", 65],
    ["minecraft:bricks", 65],
    ["minecraft:stonebrick", 66],
    ["minecraft:stone_bricks", 66],
    ["create:cut_andesite", 67],
    ["create:polished_cut_andesite", 68],
    ["create:cut_andesite_bricks", 69],
    ["create:small_andesite_bricks", 70],
    ["create:cut_calcite", 71],
    ["create:polished_cut_calcite", 72],
    ["create:cut_calcite_bricks", 73],
    ["create:small_calcite_bricks", 74],
    ["create:cut_deepslate", 75],
    ["create:polished_cut_deepslate", 76],
    ["create:cut_deepslate_bricks", 77],
    ["create:small_deepslate_bricks", 78],
    ["create:cut_diorite", 79],
    ["create:polished_cut_diorite", 80],
    ["create:cut_diorite_bricks", 81],
    ["create:small_diorite_bricks", 82],
    ["create:cut_dripstone", 83],
    ["create:polished_cut_dripstone", 84],
    ["create:cut_dripstone_bricks", 85],
    ["create:small_dripstone_bricks", 86],
    ["create:cut_granite", 87],
    ["create:polished_cut_granite", 88],
    ["create:cut_granite_bricks", 89],
    ["create:small_granite_bricks", 90],
    ["create:cut_tuff", 91],
    ["create:polished_cut_tuff", 92],
    ["create:cut_tuff_bricks", 93],
    ["create:small_tuff_bricks", 94],
    ["create:rose_quartz_block", 95],
    ["create:rose_quartz_tiles", 96],
    ["create:small_rose_quartz_tiles", 97],
    ["create:industrial_iron_block", 98],
    ["create:weathered_iron_block", 99],
    ["create:asurine", 100],
    ["create:veridium", 101],
    ["create:ochrum", 102],
    ["create:limestone", 103],
    ["create:crimsite", 104],
    ["create:cut_asurine", 105],
    ["create:polished_cut_asurine", 106],
    ["create:cut_asurine_bricks", 107],
    ["create:small_asurine_bricks", 108],
    ["create:cut_veridium", 109],
    ["create:polished_cut_veridium", 110],
    ["create:cut_veridium_bricks", 111],
    ["create:small_veridium_bricks", 112],
    ["create:cut_ochrum", 113],
    ["create:polished_cut_ochrum", 114],
    ["create:cut_ochrum_bricks", 115],
    ["create:small_ochrum_bricks", 116],
    ["create:cut_limestone", 117],
    ["create:polished_cut_limestone", 118],
    ["create:cut_limestone_bricks", 119],
    ["create:small_limestone_bricks", 120],
    ["create:cut_crimsite", 121],
    ["create:polished_cut_crimsite", 122],
    ["create:cut_crimsite_bricks", 123],
    ["create:small_crimsite_bricks", 124]
]);

const COPYCAT_BLOCKS = new Set([
    "create:copycat_panel",
    "create:copycat_step"
]);

export function isCopycatMaterial(itemStack) {
    return COPYCAT_MATERIALS.has(itemStack?.typeId);
}

export function applyCopycatMaterial(block, itemStack) {
    if (!COPYCAT_BLOCKS.has(block?.typeId)) return false;
    const material = COPYCAT_MATERIALS.get(itemStack?.typeId);
    if (material === undefined) return false;
    const group = Math.floor(material / 16);
    const variant = material % 16;

    try {
        if (
            block.permutation.getState("create:copycat_group") === group &&
            block.permutation.getState("create:copycat_variant") === variant
        ) return true;
        block.setPermutation(
            block.permutation
                .withState("create:copycat_group", group)
                .withState("create:copycat_variant", variant)
        );
        block.dimension.playSound("use.stone", block.center(), { volume: 0.6, pitch: 1.2 });
        return true;
    } catch {
        return false;
    }
}
